# Bedrock Mod Catalog

Blank Git catalog template for the Minecraft Bedrock server manager. Packs you commit here become searchable in **Mod Catalog** and can be downloaded into the mod library.

## Get started

1. Unzip this archive and create a Git project on GitLab, GitHub, or another host.
2. From this folder, initialize Git (and Git LFS if you will store pack binaries with LFS):

```bash
git init
git lfs install
git add .
git commit -m "feat: initialize Bedrock mod catalog"
git branch -M main
git remote add origin <your-clone-url>
git push -u origin main
```

3. In the manager, open **Mod Catalog** and click the settings gear.
4. Enable **Git catalog**, paste the clone URL, branch `main`, and an access token if the project is private (`read_repository`).
5. Use **Test Connection**, then **Save Settings**. Wait for the sync spinner to finish before downloading packs.

Full setup notes are in `git-mod-catalog.md`. Do not commit tokens or other secrets.

## Layout

```text
README.md
catalog.json
git-mod-catalog.md
addons/
texture-packs/
maps/
skins/
worlds/
scripts/
templates/
structures/
```

Supported pack files: `.mcaddon`, `.mcpack`, `.mcworld`, `.mctemplate`, `.mcstructure`, `.zip`.

Optional images in the same folder: `thumbnail.png`, `thumbnail.jpg`, `logo.png`, `icon.png`, or `pack_icon.png`.

Folder names `addons`, `texture-packs`, `maps`, `skins`, `worlds`, and `scripts` are used to infer type when metadata does not set it.

## Adding a pack

1. Create a folder under the matching type directory, for example `addons/my-tools/`.
2. Add the pack file and an optional thumbnail.
3. Add `mod.json` in that folder (see `git-mod-catalog.md`).
4. Optionally list the pack in `catalog.json`.
5. Commit and push. The manager indexes the branch after the next sync.

Example `mod.json`:

```json
{
  "name": "Example Addon",
  "slug": "example-addon",
  "type": "addon",
  "version": "1.2.0",
  "description": "Adds extra survival tools for Bedrock servers.",
  "author": "Your Team",
  "categories": ["survival", "utility"],
  "file": "example-addon.mcaddon"
}
```

`file` may also be an array when one catalog entry should download several archives:

```json
{
  "name": "Example Combo",
  "file": ["example-addon.mcaddon", "example-world.mcworld"]
}
```

## Git LFS

Pack archives, images, and audio are stored with [Git LFS](https://git-lfs.com/) when you keep the included `.gitattributes`. JSON and Markdown stay in regular Git.

The host running the manager also needs `git-lfs` so cloned packs are real files rather than LFS pointer files.

Do not store secrets in this repository. Review pack archives before installing them onto production servers.
